#### RepositoryName	
###### RepositoryName
```
RepositoryName:learn-pr 
```

#### BranchName	
###### BranchName
```
BranchName: master
```

###### Enter the module workitem id, click [here](https://microsoftdigitallearning.visualstudio.com/Courseware/_workitems/edit/68541) to go to view/update
```
Module workitem: 68541
```

###### Enter the Target folder in github
```
Target folder in github: learn-pr/wwl-azure/introduction-to-azure-virtual-networks
```