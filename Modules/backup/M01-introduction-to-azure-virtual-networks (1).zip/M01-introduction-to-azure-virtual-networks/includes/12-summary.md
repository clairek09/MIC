Now that you have reviewed this module, you should be able to:

-	Implement virtual networks
-	Configure public IP services
-	Design and implement name resolution 
-	Design and implement cross-VNET connectivity
-	Implement virtual network routing
-	Design and implement an Azure Virtual Network NAT


##Resources

Use these resources to discover more.
