#### Click the below button to publish this module to Learn.  
###### This operation applys to applies to publish an individual module firstly to Learn platform, or update content to Learn platform.


[![Go to Build](https://courseautopubmgtv3dev.blob.core.windows.net/publiccontainer/GotoPubModule.png)](https://wwlpublish2learn.azurewebsites.net/#/pub2Module/https%253A%252F%252Fmicrosoftdigitallearning.visualstudio.com%252FDefaultCollection%252FCourseware%252F_git%252FLP_AZ_designing-implementing-microsoft-azure-networking%253Fpath%253D%25252FModules%25252FM01-introduction-to-azure-virtual-networks%2526version%253DGBmaster)