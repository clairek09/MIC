﻿using System;
using Microsoft.Exchange.WebServices.Data;
using Microsoft.Azure.KeyVault;
using System.Threading.Tasks;

namespace Microsoft.Learn.BAG.Productivity
{
    public struct NotificationEMail
    {
        public string From;
        public string Password;
        public string Domain;

        public NotificationEMail(string from, string password, string domain) => (From, Password, Domain) = (from, password, domain);
    }

    public static class Notifications
    {

        public static void SendO365HTMLEmail(NotificationEMail sender, string[] to, string subject, string body)
        {
            SendO365Email(sender, to, subject, body, BodyType.HTML); 
        }

        public static void SendO365Email(NotificationEMail sender, string[] to, string subject, string body, BodyType bt)
        {
            ExchangeService service = new ExchangeService();

            // Set specific credentials.
            service.Credentials = new WebCredentials(sender.From, sender.Password, sender.Domain);
            service.Url = new System.Uri("https://outlook.office365.com/EWS/Exchange.asmx");

            var email = new EmailMessage(service)
            {
                Subject = subject,
                Body = new MessageBody(bt, body)
            };

            foreach (string emailAddy in to)
            {
                email.ToRecipients.Add(emailAddy);
            }
            try
            {
                email.Send();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static void SendBAGLearnEmail(string to, string subject, string body)
        {
            string SecretsURI = "https://bagkeyvault.vault.azure.net";

            KeyVaultClient kvc = Utility.GetKeyVaultLogin(); 

            string email = Utility.GetKeyVaultSecretValue(kvc, SecretsURI, "BAGSystemAccount");
            string pw = Utility.GetKeyVaultSecretValue(kvc, SecretsURI, "BAGSystemAccountPassword");
            string domain = Utility.GetKeyVaultSecretValue(kvc, SecretsURI, "BAGSystemAccountDomain");

            NotificationEMail notify = new NotificationEMail(email, pw, domain);

            try
            {
                Notifications.SendO365HTMLEmail(notify, new[] { to }, subject, body);
            }
            catch (Exception ex)
            {
                throw new Exception("Could not send email. See inner exception for details.", ex); 
            }
        }
    }
}