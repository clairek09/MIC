﻿/*
 * Make requests to GitHub API. 
 * 
 * This class provides a C# layer above GitHub. It supports authentication and making a set of GitHub command requests we have found useful
 * in BAG Learn. 
 * 
 * All GitHub commands are represented as methods with parameters. This class handles converting such requests into the API syntax
 * expected by GitHub. 
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using CredentialManagement;
using RestSharp;
using RestSharp.Authenticators;
using ZetaLongPaths;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Net;
using System.Security.Cryptography;

namespace Microsoft.Learn.BAG.Productivity
{
    public class GitHubPullRequestState
    {
        public static GitHubPullRequestState Open { get; } = new GitHubPullRequestState(0, "Open");
        public static GitHubPullRequestState Closed { get; } = new GitHubPullRequestState(1, "Closed");
        public static GitHubPullRequestState All { get; } = new GitHubPullRequestState(2, "All");

        private static Dictionary<string, GitHubPullRequestState> ghToValueMapping =
            new Dictionary<string, GitHubPullRequestState>
            {
                        { "open", Open },
                        {  "closed", Closed },
                        {  "all", All }
            };

        private Dictionary<string, string> valueToGHMapping;

        public string Name { get; private set; }
        public int Value { get; private set; }

        private GitHubPullRequestState(int val, string name)
        {
            Value = val;
            Name = name;
        }

        public static IEnumerable<GitHubPullRequestState> List()
        {
            // alternately, use a dictionary keyed by value
            return new[] { Open, Closed, All };
        }

        public static GitHubPullRequestState FromString(string roleString)
        {
            return List().Single(r => String.Equals(r.Name, roleString, StringComparison.OrdinalIgnoreCase));
        }

        public static GitHubPullRequestState FromValue(int value)
        {
            return List().Single(r => r.Value == value);
        }

        public static GitHubPullRequestState FromGitHubValue(string ghValue)
        {
            return ghToValueMapping[ghValue];
        }

        public string ToGitHubString()
        {
            if (valueToGHMapping is null)
            {
                valueToGHMapping = new Dictionary<string, string>
                { { Open.Name, "open"},
                  { Closed.Name, "closed"},
                  {  All.Name, "all" }
                };
            }

            return valueToGHMapping[this.Name];
        }
    }

    public class GitHubPullRequestSortOrder
    {
        private static Dictionary<string, GitHubPullRequestSortOrder> ghToValueMapping =
            new Dictionary<string, GitHubPullRequestSortOrder>
            {
                { "created", Created },
                {  "updated", Updated },
                {  "popularity", Popularity },
                {  "long-running", LongRunning }
            };

        private Dictionary<string, string> valueToGHMapping =
            new Dictionary<string, string>
            { { Created.Name, "created"},
              { Updated.Name, "updated"},
              {  Popularity.Name, "popularity" },
              {  LongRunning.Name, "long-running" }
            };

        public static GitHubPullRequestSortOrder Created { get; } = new GitHubPullRequestSortOrder(0, "Created");
        public static GitHubPullRequestSortOrder Updated { get; } = new GitHubPullRequestSortOrder(1, "Updated");
        public static GitHubPullRequestSortOrder Popularity { get; } = new GitHubPullRequestSortOrder(2, "Popularity");
        public static GitHubPullRequestSortOrder LongRunning { get; } = new GitHubPullRequestSortOrder(3, "LongRunning");


        public string Name { get; private set; }
        public int Value { get; private set; }

        private GitHubPullRequestSortOrder(int val, string name)
        {
            Value = val;
            Name = name;
        }

        public static IEnumerable<GitHubPullRequestSortOrder> List()
        {
            // alternately, use a dictionary keyed by value
            return new[] { Created, Updated, Popularity, LongRunning };
        }

        public static GitHubPullRequestSortOrder FromString(string roleString)
        {
            return List().Single(r => String.Equals(r.Name, roleString, StringComparison.OrdinalIgnoreCase));
        }

        public static GitHubPullRequestSortOrder FromValue(int value)
        {
            return List().Single(r => r.Value == value);
        }

        public static GitHubPullRequestSortOrder FromGitHubValue(string ghValue)
        {
            return ghToValueMapping[ghValue];
        }

        public string ToGitHubString()
        {
            return valueToGHMapping[this.Name]; 
        }
    }

    public class GitHubAPI
    {
        private Credential credentials;
        private string repoName;

        const string apiBase = "https://api.github.com";


        // Load the API class without any authentication credentials. 
        public GitHubAPI(string _repoName) => (credentials, repoName) = (null, _repoName);

        // Load the saved authentication credentials on Windows signified by the credentialsLookup string. 
        public GitHubAPI(string _repoName, string credentialsLookup) : this(_repoName) => credentials = LoadGitHubCredentials(credentialsLookup);

        // Encapsulate logic for making an authenticated GitHub request. 
        public IRestResponse MakeGitHubRequest(string cmd)
        {
            return MakeGitHubRequest(cmd, Method.GET, null);
        }

        // Support a POST body. 
        public IRestResponse MakeGitHubRequest(string cmd, Method method, string body)
        {
            var client = new RestClient(apiBase);
            RestSharp.RestRequest req;

            if (method == Method.GET)
            {
                req = new RestRequest(cmd);
            } else 
            {
                req = new RestRequest(cmd, method);
                req.AddParameter("application/json; charset=utf-8", body, ParameterType.RequestBody);
                req.RequestFormat = DataFormat.Json;
            }

            if (credentials != null)
            {
                client.Authenticator = new HttpBasicAuthenticator(credentials.Username, credentials.Password);
            }
            IRestResponse resp = client.Execute(req);

            CheckHTTPReturnStatus(resp);

            return resp;
        }

        // Check if a response from GitHub is valid. We will error out on any non-OK response, which is usually a sign that 
        // we have exceeded the API rate limit. 
        public void CheckHTTPReturnStatus(IRestResponse response)
        {
            if (response.ErrorException != null)
            {
                int rateLimit;
                bool success = Int32.TryParse(response.Headers.FirstOrDefault(t => t.Name == "X-RateLimit-Remaining").Value.ToString(), out rateLimit);
                // Check for API rate limit exceeded. 
                if (success && rateLimit == 0)
                {
                    throw new Exception("ERROR: Rate limit exceeded for GitHub API. 5,000 requests exceeded in the past hour. Wait one hour before attempting to use the same GitHub account again.");
                }
            } else
            {
                // Created can come back for post requests (e.g., pull request creation). 
                if (!(response.StatusCode == HttpStatusCode.OK || response.StatusCode == HttpStatusCode.Created))
                {
                    throw new WebException($"HTTP status code error (non-200 response) returned. Error was: {response.StatusCode.ToString()}");
                }
            }
        }

        // Make a request to GitHub to get a file, then save that file to disk. 
        public void SaveGitHubFileToDisk(string sha, string saveFilePath)
        {
            var dataUri = $"/repos/{repoName}/git/blobs/{sha}";

            var fileResp = MakeGitHubRequest(dataUri);

            JObject jsonData = JObject.Parse(fileResp.Content);

            // Some of our paths exceed 260 chars, so use ZetaLongPaths to work around I/O errors. 
            ZlpIOHelper.WriteAllBytes(saveFilePath, System.Convert.FromBase64String((string)(jsonData["content"])));
        }

        // Get the tree just at the specified level. 
        public IRestResponse GetTree(string branch, string dir)
        {
            string treeCmd = $"/repos/{repoName}/git/trees/{branch}:{dir}";

            return MakeGitHubRequest(treeCmd);
        }

        // Get the recursive tree for the specified directory. 
        // NOTE: At a certain number of files (I believe it's >1K in a directory), the recursive 
        // tree op will fail. I don't think this will be an issue unless someone is seriously
        // abusing Git, frankly. 
        public IRestResponse GetTreeRecursive(string branch, string dir)
        {
            string treeCmd = $"/repos/{repoName}/git/trees/{branch}:{dir}?recursive=1";

            return MakeGitHubRequest(treeCmd);
        }



        // Pull requests can be multi-pages, and GitHub has a funky, HTTP header-based way of handling paging. 
        // To abstract this, we support a parameter, prevReq, that points to the last request. 
        // All first requests should have prevResp (the previous response) supplied as null; subsequent requests should include the 
        // last request so we can get the next page correctly. 
        public IRestResponse GetPullRequestFiles(int prNumber, IRestResponse prevResp)
        {
            string prCmd = $"/repos/{repoName}/pulls/{prNumber}/files";
            return HandlePagedResponse(prCmd, prevResp);
        }

        public IRestResponse GetPullRequestIssuesComments(int prNumber, IRestResponse prevResp)
        {
            string prCmd = $"/repos/{repoName}/issues/{prNumber}/comments";
            return HandlePagedResponse(prCmd, prevResp);
        } 

        public JToken FindInIssueComments(int prNumber, string substr)
        {
            JToken result = null;

            IRestResponse resp = this.GetPullRequestIssuesComments(prNumber, null);
            while (resp != null) {
                JArray comments = JArray.Parse(resp.Content);
                foreach (var comment in comments)
                {
                    if (((string)comment["body"]).IndexOf(substr) != -1)
                    {
                        result = comment;
                        break;
                    }
                }

                resp = this.GetPullRequestIssuesComments(prNumber, resp);
            }

            return result;        
        }

        /// <summary>
        /// Get the pull requests for the specified repo. 
        /// </summary>
        /// <param name="repo">The name of the repo to examine pull requests from.</param>
        /// <param name="state">The state of the pull requests to retrieve. Values are All, Open, and Closed.</param>
        /// <returns>An IRestResponse (RestSharp library) from which the response contents can be retrieved.</returns>
        public IRestResponse GetPullRequests(GitHubPullRequestState state, IRestResponse prevResp)
        {
            string prCmd = $"/repos/{repoName}/pulls?state={state.ToGitHubString()}";
            return HandlePagedResponse(prCmd, prevResp); 
        }

        // Save a tree to the specified location on disk. 
        public string SaveGitHubTreeToDisk(string branch, string repoPath, string targetFolderPath)
        {
            // Create the directory on the file share.
            string repoNameWinPath = repoName.Replace("/", "-");
            string dateTimeNow = DateTime.Now.ToString("yyyy-dd-M-HH-mm-ss");
            targetFolderPath = Path.Combine(new[] { targetFolderPath, $"{repoNameWinPath}-{branch}", dateTimeNow });
            string branchFileized = branch.Replace("/", "-");
            string repoLocalPath = Path.Combine(new[] { targetFolderPath, repoPath.Replace("/", "\\") });
            ZlpIOHelper.CreateDirectory(repoLocalPath);

            // Get the recursive tree of this dependency. 
            IRestResponse treeResp = this.GetTreeRecursive(branch, repoPath);

            JObject treeData = JObject.Parse(treeResp.Content);

            // If the truncated field is true, we need to error out, as we can't retrieve all of the files.
            if (treeData["truncated"].ToString() == "true")
            {
                throw new Exception($"ERROR: A tree we attempted to recurse returned a truncated value of true. This means we cann't successfully retrieve all of the files in the tree. Erroring out the operation.");
            }

            if (treeData.ContainsKey("tree"))
            {
                foreach (var treeFile in treeData["tree"])
                {
                    // In a tree recursion request, you're going to get a list of tree objects for directories. 
                    // Since the contents are also included in this response, the tree request can be ignored. 
                    if (treeFile["type"].ToString() == "tree")
                    {
                        continue;
                    }

                    // Create the path for this file.
                    string treeFilePath;
                    string downloadPath;

                    string treeFileStr = treeFile["path"].ToString();
                    int lastIndex = treeFileStr.LastIndexOf('/');
                    if (lastIndex != -1)
                    {
                        string treeFileRelPath = treeFileStr.Substring(0, lastIndex);
                        treeFilePath = Path.Combine(new[] { repoLocalPath, treeFileRelPath });
                        ZlpIOHelper.CreateDirectory(treeFilePath);
                    }
                    else
                    {
                        treeFilePath = repoLocalPath;
                    }
                    downloadPath = Path.Combine(new[] { repoLocalPath, treeFileStr.Replace("/", "\\") });

                    string sha = treeFile["sha"].ToString();

                    this.SaveGitHubFileToDisk(sha, downloadPath);
                }
            }

            return repoLocalPath;
        }

        private Credential LoadGitHubCredentials(string lookup)
        {
            Credential credentials = new Credential();
            credentials.Target = lookup;
            if (!credentials.Load())
            {
                throw new Exception("Could not load GitHub credentials from local computer.");
            }

            return credentials;
        }

        private IRestResponse HandlePagedResponse(string baseUrl, IRestResponse prevResp)
        {
            // If prevReq is null, just do a straight request. 
            if (prevResp == null)
            {
                return MakeGitHubRequest(baseUrl);
            }
            else
            {
                string reqUrl;
                IRestResponse nextResp = null;

                // If prevReq is NOT null, look for the paging header and get the next page. 
                // If the next paging header is not found, then we're done - return null. 
                // Check for null from this, as a PR with no paging will have no Link header. 
                Parameter output = prevResp.Headers.FirstOrDefault(t => t.Name == "Link");

                if (output != null)
                {
                    string linkVal = output.Value.ToString();

                    // Next link could be in first or second position - find it wherever it exists. 
                    string[] linkValSplit = linkVal.Split(',');

                    var results = Array.FindAll(linkValSplit, s => s.Contains("rel=\"next\""));
                    if (results.Length != 0)
                    {
                        string[] nextLink = results[0].Split(';');
                        reqUrl = nextLink[0].Trim().Trim("<>".ToCharArray());

                        nextResp = MakeGitHubRequest(reqUrl);
                    }
                }

                return nextResp;
            }
        }

        public IRestResponse CreatePullRequest(string title, string head, string targetBranch, string body)
        {
            string reqString = $"/repos/{repoName}/pulls";
            string jsonRequest = $@"
{{
    ""title"" : ""{title}"",
    ""body"" : ""{body}"",
    ""head"" : ""{head}"",
    ""base"" : ""{targetBranch}""
}}
";
            return MakeGitHubRequest(reqString, Method.POST, jsonRequest); 
        }

        // Close a pull request. 
        public IRestResponse ClosePullRequest(string pullNumber)
        {
            string reqString = $"/repos/{repoName}/pulls/{pullNumber}";
            string jsonRequest = $@"
{{
    ""state"" : ""closed""
}}
";

            return MakeGitHubRequest(reqString, Method.PATCH, jsonRequest); 
        }


        public IRestResponse AddIssueComment(string issueNumber, string comment)
        {
            string reqString = $"/repos/{repoName}/issues/{issueNumber}/comments";
            string jsonRequest = $@"
{{
    ""body"" : ""{comment}""
}}
";
            return MakeGitHubRequest(reqString, Method.POST, jsonRequest); 

        }

        public IRestResponse GetUser(string username)
        {
            string reqString = $"/users/{username}";

            return MakeGitHubRequest(reqString);
        }
    }
}