﻿using System;
using System.Security;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using CredentialManagement;
using Microsoft.Azure.KeyVault;
using Microsoft.Azure.KeyVault.Models;

namespace Microsoft.Learn.BAG.Productivity
{
    public static class Utility
    {
        public static String SecureStringToString(SecureString value)
        {
            IntPtr valuePtr = IntPtr.Zero;
            try
            {
                valuePtr = Marshal.SecureStringToGlobalAllocUnicode(value);
                return Marshal.PtrToStringUni(valuePtr);
            }
            finally
            {
                Marshal.ZeroFreeGlobalAllocUnicode(valuePtr);
            }
        }

        public static async Task<string> GetToken(string authority, string resource, string scope)
        {
            // Get credentials for baglauto from Azure. 
            var result = await GetAccessToken("downloadgithubservice://azureaccess", authority, resource, scope);
            return result;
        }

        public static async Task<string> GetAccessToken(string credsLookup, string authority, string resource, string scope)
        {
            // Retrieve client ID and client key from Credential Manager. 
            var cmService = new Credential();
            cmService.Target = credsLookup;
            if (!cmService.Load())
            {
                throw new Exception("Could not load secrets for DownloadGitHubService AAD application from local computer.");
            }

            var authenticationContext = new AuthenticationContext(authority);
            var credential = new ClientCredential(cmService.Username, cmService.Password);
            var result = await authenticationContext
                .AcquireTokenAsync(resource, credential);
            if (result == null)
            {
                throw new InvalidOperationException("Failed to obtain the JWT token");
            }
            string token = result.AccessToken;
            return token;
        }

        public static KeyVaultClient GetKeyVaultLogin()
        {
            KeyVaultClient kvc = new KeyVaultClient(new KeyVaultClient.AuthenticationCallback(Utility.GetToken));
            return kvc;
        }

        public static string GetKeyVaultSecretValue(KeyVaultClient kvc, string secretsUri, string secret)
        {
            SecretBundle secretRet = System.Threading.Tasks.Task.Run(() => kvc.GetSecretAsync(
    $"{secretsUri}/secrets/{secret}")).ConfigureAwait(false).GetAwaiter().GetResult();

            return secretRet.Value;
        }
    }
}
