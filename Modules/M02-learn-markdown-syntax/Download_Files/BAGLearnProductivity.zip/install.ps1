﻿# Installs all of our core PowerShell modules and cmdlets onto a user's machine. 
# Once installed like this, cmdlets can be called from a PowerShell session with no other changes required
# to a user's environment. 

$installDir = "\\fsu\shares\baglearn\BAGLearnProductivity"

# Get user's Documents folder. 
$installFolder = Join-Path -Path ([Environment]::GetFolderPath("MyDocuments")) -ChildPath "WindowsPowershell\Modules"
if (-Not (Test-Path $installFolder)) {
    New-Item -ItemType Directory -Path $installFolder
}

# Install all Powershell module directories, rewriting old versions. 
$gitInstallFolder = Join-Path -Path $installFolder -Child "GitManagement"

Copy-Item -Path (Join-Path -Path $installDir -ChildPath "GitManagement") -Destination $installFolder -Force -Recurse

Unblock-File -Path (Join-Path -Path $gitInstallFolder -ChildPath "GitManagement.psm1")

write-host("GitManagement utilities installed! Use Help to get more information on the cmdlets associated with this package.")
write-host("")
write-host("Get-Help Rename-LearnItem")
