

# Make sure Windows Credential Manager is installed. 
if (-Not (-Get-Module -ListAvailable -Name "CredentialManager")) {
    Install-Module CredentialManager
}

# Get stored creds
$creds = get-storedcredential -target "crm:https://crm.dynamics.com" -type generic

# Connect to org and perform work. 
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

$CRMOrgs = Get-CrmOrganizations –ServerUrl https://CRM363529.crm.dynamics.com –Credential $creds

# Get connection object. 
$CRMConn = Get-CrmConnection –ServerUrl https://CRM363529.crm.dynamics.com –Credential $creds -OrganizationName $CRMOrgs[0].UniqueName

