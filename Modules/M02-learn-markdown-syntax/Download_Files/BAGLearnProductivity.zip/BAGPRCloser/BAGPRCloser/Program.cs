﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Learn.BAG.Productivity;
using RestSharp;
using Newtonsoft.Json.Linq;
using Microsoft.Azure.KeyVault;
using Microsoft.Azure.KeyVault.Models;
using System.Web.UI;

namespace BAGPRCloser
{
    class Program
    {
        static void Main(string[] args)
        {

#if DEBUG
            List<string> toEmail = new List<string> { "jayallen@microsoft.com" };
#else
            List<string> toEmail = new List<string> { "bag-l@microsoft.com", "learn-repo-managers@microsoft.com" };
#endif

            string[] repos = new string[] { "MicrosoftDocs/learnshared", "MicrosoftDocs/learn-dynamics-pr", "MicrosoftDocs/learn-bizapps-pr", "MicrosoftDocs/learn-pr", "MicrosoftDocs/learn-windows-pr", "MicrosoftDocs/learn-m365-pr", "MicrosoftDocs/learn-xamarin-pr", "MicrosoftDocs/learn-certs-pr" };

            StringBuilder sbWarnList = new StringBuilder();
            StringBuilder sbCloseList = new StringBuilder();

            foreach (string repo in repos)
            {
                List<JToken> warnList = new List<JToken>();
                List<JToken> closeList = new List<JToken>();

                // Check aging pull requests on the repo. 
                Console.WriteLine($"Pulling data for repo {repo}...");

                GitHubAPI gh = new GitHubAPI(repo, "https://githubwebhook");

                // First, let's collect all of the items we need, and put them in a dictionary. We can then 
                // sort the dictionary by delta to order them from largest to smallest delta. 
                IRestResponse resp = gh.GetPullRequests(GitHubPullRequestState.Open, null);

                while (resp != null)
                {
                    var prData = JArray.Parse(resp.Content);

                    foreach (var pr in prData.Root)
                    {
                        // Look at the last updated date, and the delta from today. 
                        // If the delta is 21-30 days, put it on the close warning list. 
                        // If it's staler than 30 days, close it. 
                        DateTime updatedAt = DateTime.Parse(pr["updated_at"].ToString());
                        TimeSpan tsMeasure = DateTime.Now - updatedAt;
                        pr["daysOld"] = tsMeasure.Days;

                        if (tsMeasure.Days >= 21 && tsMeasure.Days <=30)
                        {
                            // Warn.
                            warnList.Add(pr);
                        } else if (tsMeasure.Days > 30)
                        {
                            closeList.Add(pr);

                            //!TODO: Un-comment when we're ready to go live.  
                            /*JObject jsonData = JObject.Parse(resp.Content);
                            string pullNumber = (string)jsonData["number"];

                            // Add a comment to the PR about why we're closing it. 
                            gh.AddIssueComment(pullNumber, "Automatic Closure - No updates have been made to this PR in more than 30 days, so closing it as stale. You can re-open if you need to continue working on it.");

                            // Close it. 
                            resp = gh.ClosePullRequest(pullNumber);*/

                        }
                    }

                    resp = gh.GetPullRequests(GitHubPullRequestState.Open, resp);
                }

                // Now that we have all of the responses for this repo, add them to the appropriate report. 
                sbWarnList.Append($"<h3>{repo}</h3>");

                if (warnList.Count == 0)
                {
                    sbWarnList.Append("<em>No expiring PRs found</em>");
                }
                else
                {

                    sbWarnList.Append(@"<table style='border: 1px solid black;padding: 15px;border-spacing:5px;'>
    <th style='text-align: left;'>PR ID</th>
    <th style='text-align: left;'>Title</th>
    <th style='text-align: left;'>Created By</th>
    <th style='text-align: left;'>Last Updated</th>
    ");

                    List<JToken> sortedList = warnList.OrderByDescending(o => ((int)(o["daysOld"]))).ToList();
                    foreach (var pr in sortedList)
                    {
                        sbWarnList.Append("<tr>");
                        sbWarnList.Append($"<td><a href='{pr["html_url"].ToString()}'>{pr["number"].ToString()}</a></td>");
                        sbWarnList.Append($"<td>{pr["title"].ToString()}</td>");
                        sbWarnList.Append($"<td>{pr["user"]["login"].ToString()}</td>");
                        sbWarnList.Append($"<td>{pr["daysOld"].ToString()} days ago</td>");
                        sbWarnList.Append("</tr>");
                    }
                    sbWarnList.Append("</table>");
                }

                sbCloseList.Append($"<h3>{repo}</h3>");

                if (closeList.Count == 0)
                {
                    sbCloseList.Append("<em>No closable PRs found</em>");
                }
                else
                {
                    sbCloseList.Append(@"<table style='border: 1px solid black;padding: 15px;border-spacing:5px;'>
    <th style='text-align: left;'>PR ID</th>
    <th style='text-align: left;'>Title</th>
    <th style='text-align: left;'>Created By</th>
    <th style='text-align: left;'>Days Old</th>
    ");

                    List<JToken> sortedList = closeList.OrderByDescending(o => ((int)(o["daysOld"]))).ToList();
                    foreach (var pr in sortedList)
                    {
                        sbCloseList.Append("<tr>");
                        sbCloseList.Append($"<td><a href='{pr["html_url"].ToString()}'>{pr["number"].ToString()}</a></td>");
                        sbCloseList.Append($"<td>{pr["title"].ToString()}</td>");
                        sbCloseList.Append($"<td>{pr["user"]["login"].ToString()}</td>");
                        sbCloseList.Append($"<td>{pr["daysOld"].ToString()} days ago</td>");
                        sbCloseList.Append("</tr>");
                    }
                    sbCloseList.Append("</table>");
                }
            }

            // Bring the two halves of the email together into a new message. 
            StringBuilder sbFullMessage = new StringBuilder();
            sbFullMessage.Append(@"<h2>PRs Nearing Automated Closure</h2>");
            sbFullMessage.Append(@"<p>The following PRs have not been updated in close to 30 days, and are scheduled for closure. They will be closed in one week from now if they are still open with no activity.</p>
");
            sbFullMessage.Append(sbWarnList);

            sbFullMessage.Append(@"<h2>Automatically Closed PRs</h2>");
            sbFullMessage.Append(@"<p>The following PRs have had no activity in 30 days, and have been closed. You may re-open them if you need to continue working on them.</p>");

            sbFullMessage.Append(sbCloseList);

            // Send the report to the team via email. 
            string SecretsURI = "https://bagkeyvault.vault.azure.net";

            KeyVaultClient kvc = new KeyVaultClient(new KeyVaultClient.AuthenticationCallback(Utility.GetToken));

            SecretBundle secret = Task.Run(() => kvc.GetSecretAsync(
    $"{SecretsURI}/secrets/BAGSystemAccount")).ConfigureAwait(false).GetAwaiter().GetResult();

            string email = secret.Value;

            secret = Task.Run(() => kvc.GetSecretAsync(
    $"{SecretsURI}/secrets/BAGSystemAccountPassword")).ConfigureAwait(false).GetAwaiter().GetResult();

            string pw = secret.Value;
            NotificationEMail notify = new NotificationEMail(email, pw, "REDMOND");

            Notifications.SendO365HTMLEmail(notify, toEmail.ToArray(), "Pull Request Automated Closure Report", sbFullMessage.ToString());
        }
    }
}
