﻿# Rename a large number of directories and files. 
# Additionally, generate the entries for .openpublishing.redirection.json to ensure we don't get 404 on old files. 

$ErrorActionPreference = "stop" 

$dirsCsv = "C:\temp\dirs.csv"
$filesCsv = "C:\temp\files.csv"

#!TODO: $productName should be genericized somewhere - an entry in one of the config files, perhaps? 
# Need to rethink the use of multiple CSVs here - a single JSON file would be a lot more flexible. 
$repoBase = "C:\Users\jayallen\documents\git\jay\learn-dynamics-pr"
$productName = "learn-dynamics-pr"
$productsBase = Join-Path -Path $repoBase -childpath $productName
$openPubFile = Join-Path -Path $repoBase -ChildPath ".openpublishing.redirection.json"

$dirs = import-csv -path $dirsCsv -delimiter ";" 
$topDirs = $dirs | ? { -Not $_.current_folder.Contains("\") }

$changedFiles = @{}

foreach ($topDir in $topDirs) {
    $topDirPostProcessName = ""

    if ($topDir.changed -eq "x") {
        $topDirPostProcessName = $topDir.proposed_subfolder
    } else {
        $topDirPostProcessName = $topDir.current_folder
    }

    # Rename sub-folders. 
    # Get a list of all subdirectories in this dir in our spreadsheet. 
    $subDirs = $dirs | ? { $_.current_folder.StartsWith($topDir.current_folder + "\") }

    foreach ($subDir in $subDirs) {
        if (($subDir.changed -eq "x") -and ($subDir.proposed_subfolder -ne "")) {
            $fullSubdirPath = join-path -path $productsBase -childpath $subDir.current_folder

            # Before renaming, get a list of files in the directory. 
            # We will need to generate redirects for these. 
            # The files may also need to be renamed themselves if they have an entry in the file CSV. 
            gci -Path $fullSubdirPath -Filter "*.yml" | foreach-object {
                $prevRelFile = Join-Path -Path $subdir.current_folder -ChildPath $_.Name
                $rename = $subdir.proposed_subfolder.Trim()
                $changedFiles[$prevRelFile] =  $topDirPostProcessName + "\$rename\" + $_.Name
            }

            write-host("Rename " + $fullSubdirPath + " to " + $subdir.proposed_subfolder.Trim())
            rename-item -Path $fullSubdirPath -NewName $subdir.proposed_subfolder.Trim()
        }
    }

    if ($topDir.changed -eq "x") {
        # Now, rename the top level directory. 
        if ($topDir.proposed_subfolder -Ne "") {
            $fullDirPath = join-path -path $productsBase -childpath $topDir.current_folder
            rename-item -Path $fullDirPath -NewName $topDirPostProcessName
        } 
    }
}

# Now rename any individual files that need renaming. 
# If we changed the dir name, we can look up the file in $changedFiles to get its old relative path, 
# as well as its new relative path. 
$files = import-csv -path $filesCsv -delimiter ";" 
foreach ($file in $files) {
    if ($file.changed -eq "x") {
        # File was formatted oddly - need to eliminate the comma in the first field. 
        $currentFileName = $file.current_file_name.Trim()
        $proposedFileName = $file.proposed_file_name.Trim()
        $currRelPath = $currentFileName -replace ",", "\"
        if ($changedFiles.ContainsKey($currRelPath)) {
            $actualCurrRelPath = $changedFiles[$currRelPath]
        } else {
            $actualCurrRelPath = $currRelPath
        }

        $fullCurrPath = join-path -path $productsBase -childPath $actualCurrRelPath

        rename-item -Path $fullCurrPath -NewName $proposedFileName
        $newRelPath = join-path -path (split-path -path $actualCurrRelPath) -ChildPath $proposedFileName

        $changedFiles[$currRelPath] = $newRelpath
    }
}


# Open the .openpublishing.redirection.json file, and generate a redirect for every item in the $changedFiles hash. 
$redirectJson = Get-Content $openPubFile | Out-String | ConvertFrom-Json

foreach ($file in $changedFiles.Keys) {

  # Different file types are handled differently. Crack open the YAML file and find out what redirection style we need to use
  # based on the file type. 
  $newRelativePath = $changedFiles[$file]
  $currentFilePath = Join-Path -Path $productsBase -ChildPath $newRelativePath

  # Redirection has this bizarre thing where the .yml extension on files needs to be a .md extension. 
  # Don't ask me...I just work here. 
  
  $line = Get-Content -Path $currentFilePath -First 1
  $type = $line.Split(":")[1].Trim()

  if ($type -eq "LearningPath" ) {
      $oldPathName = Split-Path -Path (Split-Path -Path $file) -Leaf
      $newPathName = Split-Path -Path (Split-Path -Path $newRelativePath) -Leaf
      $fileForRedirect = (split-path -Path $file -Leaf) -replace "\.yml$", ".md"
      
      $rewriteEntry = @"
{
       "source_path": "$productName/paths/$oldPathName/$fileForRedirect",
       "redirect_url": "https://docs.microsoft.com/learn/paths/$newPathName/",
       "redirect_document_id": true
}
"@
  } elseif ($type -eq "Module") {
      $oldModuleName = (split-path -Path $file) -replace "\\", "/"
      $newModuleName = split-path -path (split-path -Path $newRelativePath) -leaf
      $fileName = (split-path -Path $file -Leaf) -replace "\.yml$", ".md"

      $rewriteEntry = @"
{
       "source_path": "$productName/$oldModuleName/index.md",
       "redirect_url": "https://docs.microsoft.com/learn/modules/$newModuleName/",
       "redirect_document_id": true
}
"@
          
  } elseif ($type -eq "ModuleUnit") {
      $oldModuleName = (split-path -Path $file) -replace "\\", "/"
      $newModuleName = split-path -path (split-path -Path $newRelativePath) -leaf
      $fileName = [io.path]::GetFileNameWithoutExtension($newRelativePath)
      $oldFilename = (split-path -Path $file -Leaf) -replace "\.yml$", ".md"

      $rewriteEntry = @"
{
       "source_path": "$productName/$oldModuleName/$oldFilename",
       "redirect_url": "https://docs.microsoft.com/learn/modules/$newModuleName/$fileName",
       "redirect_document_id": true
}
"@
  }

  $redirectJson.redirections += (ConvertFrom-Json -InputObject $rewriteEntry)
}

# Write it!
Set-Content $openPubFile (ConvertTo-Json $redirectJson) -Force