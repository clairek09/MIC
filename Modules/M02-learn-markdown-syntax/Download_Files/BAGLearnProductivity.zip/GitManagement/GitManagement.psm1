﻿<#

.SYNOPSIS

Changes the name of a file or directory in a Learn repository, and generates the appropriate file/folder redirects for Learn. 

.DESCRIPTION

Rename-LearnItem changes the name of a file or directory in a Learn repository. Because every published file whose name changes has to be redirected, it also adds the appropriate syntax
to the .openpublishing.redirection.json file to ensure the redirect is in place before you check in your changes. 

This command should be run somewhere in a local Learn GitHub repo. This command also requires that Git Tools be installed on your system. 

.EXAMPLE

To rename a learning path or module, navigate to the file that you want to rename in Git in PowerShell on your file system. This will be wherever you've cloned your GitHub repos on your computer. E.g.:

cd c:\users\jalle\Documents\git\jay\learn-dynamics-pr\learn-dynamics-pr\paths

Then, rename the folder: 

Rename-LearnItem -ItemPath .\work-accounts-receivable-d365-finance-ops -NewName NewPathName

.EXAMPLE

To rename a file: 

Rename-LearnItem -ItemPath .\01-introduction-blahblahblah.yml -NewName 01-intro.yml

.PARAMETER ItemPath

The file you want to rename. Can be a relative or absolute path. 

.PARAMETER NewName

The name to which you want to change the folder or file. 

.NOTES

You can use this script to rename a file if you already renamed the containing file's folder in the same session. The tool automatically detects this condition, and changes the redirection JSON file's past entries as needed. 

#>

function Rename-LearnItem {
    Param(
        [Parameter(Mandatory=$True)]
        [string]$ItemPath,
        [Parameter(Mandatory=$True)]
        [string]$NewName
    )

    $ItemFullPath = Resolve-Path -Path $ItemPath

    # Find the git base. 
    $gitBase = (git rev-parse --show-toplevel) -replace "/", "\"
    # Remove leading slash.
    $repoName = Split-Path -Path $gitBase -Leaf

    # Get the path of the item we're redirecting relative to the base. 
    # We will need this for redirection syntax.
    #!TODO: I can't find a way to do this that doesn't involve pushing/popping location.
    push-location $gitBase
    $itemRelLoc = (Resolve-Path -Path $ItemFullPath -Relative).SubString(2) -replace "\\", "/"
    Pop-Location

    # Find .openpublishing.redirection.json in the root dir. If it doesn't exist, just create it. 
    $redirPath = Join-Path -Path $gitBase -ChildPath ".openpublishing.redirection.json"
    if (Test-Path $redirPath) {
        $redirectJson = Get-Content -Encoding UTF8 $redirPath | Out-String | ConvertFrom-Json   
    } else {
        $redirTxt = @"
{
    "redirections" : []
}
"@
        $redirectJson = ConvertFrom-Json $redirTxt
    }

    # Determine what type the item is.
    # Save the renamed portion so that we can look for previous entries that might be used the old name
    # as a redirection target. 
    if (Test-Path -Path $ItemFullPath -PathType Container) {
        $redirTarget = ""

        # Rename the item. 
        Rename-Item -Path $ItemFullPath -NewName $NewName

        # Get new directory name. 
        $NewDirectoryPath = Join-Path -Path (Split-Path -Path $ItemFullPath) -ChildPath $NewName

        # Now time to generate the redirection syntax. 
        # If a directory, need to determine if this is a learning path, or a module. 
        # Look at the top line of index.yml to determine. 
        $line = Get-Content -Encoding UTF8 -Path (Join-Path -Path $NewDirectoryPath -ChildPath "index.yml") -First 1
        $type = $line.Split(":")[1].Trim()

        if ($type -eq "LearningPath") {
            # We only need to redirect the path. Simple!
            $directoryOnly = Split-Path -Path $ItemFullPath -Leaf
            $redirUrl = "https://docs.microsoft.com/learn/paths/$NewName/"

            $rewriteEntry = @"
{
        "source_path": "$repoName/paths/$directoryOnly/index.md",
        "redirect_url": "$redirUrl",
        "redirect_document_id": true
}
"@

            $redirectJson.redirections += (ConvertFrom-Json -InputObject $rewriteEntry)

            $RenamedPart = $directoryOnly
        } elseif ($type -eq "Module") {
            # Redirects will need to be generated for every file. More complicated. 
            # Redirect module first. 
            # Modules are weird because it's basically the repo name + modules + the relative path underneath
            # the product name folder. 
            # This is all very break-y - if a repo uses a different folder structure, it won't work correctly. 
            $redirTarget = $NewName
            $redirUrl = "https://docs.microsoft.com/learn/modules/$NewName/"

            $rewriteEntry = @"
{
       "source_path": "$itemRelLoc/index.md",
       "redirect_url": "$redirUrl",
       "redirect_document_id": true
}
"@

            $redirectJson.redirections += (ConvertFrom-Json -InputObject $rewriteEntry)
               
            # Now redirect kidlets. 
            $redirFiles = gci -Path $NewDirectoryPath -File
            foreach ($redirFile in $redirFiles) {
                $filename = split-path -leaf $redirFile 
                Rename-LearnFile $redirFile.FullName $filename $repoName $redirectJson $itemRelLoc
            }
            

            # Now see if we need to re-re-name the renamed path - i.e., see if it's been renamed before, and the entry needs to be changed. 
            $replaceUrls = $redirectJson.redirections | where { $_.redirect_url -match $itemRelLoc } 
            foreach ($replaceUrl in $replaceUrls) {
                $replaceUrl.redirect_url = $redirUrl -replace $itemRelLoc, $newName
            }

            $RenamedPart = $itemRelLoc
        }
    } else {
        # Rename the individual file. 
        Rename-Item -Path $ItemFullPath -NewName $NewName        
        Rename-LearnFile $ItemFullPath $NewName $repoName $redirectJson

        $RenamedPart = [System.IO.Path]::GetFileNameWithoutExtension($ItemFullPath)
    }

    # Has this element been renamed before? If so, redirect to the new name. 
    $replaceUrls = $redirectJson.redirections | where { $_.redirect_url -match $RenamedPart } 
    foreach ($replaceUrl in $replaceUrls) {
        $replaceUrl.redirect_url = $replaceUrl.redirect_url -replace $RenamedPart, $newName
    }

    # Write it!
    Set-Content $redirPath (ConvertTo-Json $redirectJson) -Force
}

function Rename-LearnFile {
    Param(
        [Parameter(Mandatory=$True)]
        [string]$File,
        [Parameter(Mandatory=$True)]
        [string]$NewName,
        [Parameter(Mandatory=$True)]
        [string]$RepoName,
        [Parameter(Mandatory=$True)]
        [object]$RedirectJson,
        [string]$OldParentDirectory
    )

    $newModuleName = split-path -path (split-path -Path $File) -leaf
    if ($OldParentDirectory.Length -eq 0) {
        $OldParentDirectory = $newModuleName
    }

    $fileName = [io.path]::GetFileNameWithoutExtension($NewName)

    # We already did the root redirect - ignore index.yml. 
    if ($filename -eq "index") {
        return
    }

    $oldFilename = (split-path -Path $File -Leaf) -replace "\.yml$", ".md"

    $rewriteEntryItem = @"
{
        "source_path": "$OldParentDirectory/$oldFilename",
        "redirect_url": "https://docs.microsoft.com/learn/modules/$newModuleName/$fileName",
        "redirect_document_id": true
}
"@

    $RedirectJson.redirections += (ConvertFrom-Json -InputObject $rewriteEntryItem)
}

Export-ModuleMember Rename-LearnItem