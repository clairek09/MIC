﻿# Process all YAML files to include a header 

$base = "C:\Users\jayallen\Documents\git\jay\learn-dynamics-pr\learn-dynamics-pr"

# Get files, but exclude certain folders. 
$files = gci $base -Filter "*.yml" -Recurse | ? { $_.FullName -inotmatch 'dyn365-business-central' }
foreach ($fileObj in $files) {
    # Get the file as YAML data just for easy if-elsing on values. 
    # Easiest way to skip processing of quiz files. 

    try {
        $yaml = Get-Content -Path $fileObj.FullName | out-string | ConvertFrom-Yaml
    } catch { 
        write-host("ERROR: Could not open file as YAML - file is corrupt: " + $fileObj.FullName) 
        exit
    }
    if ($yaml.ContainsKey("quiz")) {
        continue
    }

    # Get top line of file to figure out what type of file it is. 
    $line = Get-Content -Path $fileObj.FullName -First 1
    if ($line.StartsWith("#")) {
        $type = $line.Split(":")[1].Trim()

        $file = Get-Content -Path $fileObj.FullName | out-string

        if ($type -eq "LearningPath") {
            $file = $file -replace "summary:\s*(.+)\s*`r`n", "summary: |`r`n  [!include[](../../includes/lp-banner.md)]`r`n`r`n  `$1`r`n"

            
            Set-Content $fileObj.FullName $file -Encoding UTF8 -Force
        } elseif ($type -eq "Module") {
            $file = $file -replace "summary:\s*(.+)\s*`r`n", "summary: |`r`n  [!include[](../includes/module-banner.md)]`r`n`r`n  `$1`r`n"

            
            Set-Content $fileObj.FullName $file -Encoding UTF8 -Force
        } elseif ($type -eq "ModuleUnit") {
            $file = $file -replace "content: \|\s*`r`n\s*(.+)", "content: |`r`n  [!include[](../includes/unit-banner.md)]`r`n`  `$1"

            Set-Content $fileObj.FullName $file -Encoding UTF8 -Force
        } 
    }
}