﻿# Create a CSV of all YAML files, their paths, and parent directory names. 

$base = "C:\Users\jayallen\Documents\git\jay\learn-dynamics-pr\learn-dynamics-pr"
$directories = @{}

$filesCsv = "C:\temp\files.csv"
$dirCsv = "C:\temp\dirs.csv"

if (Test-Path $filesCsv) {
    Remove-Item -Path $filesCsv
}

if (Test-Path $dirCsv) {
    Remove-Item -Path $dirCsv
}

## List all dirs two levels deep. 
push-location $base 
$dirs = gci $base -Directory -Depth 1 | Resolve-Path -Relative
foreach ($dirPath in $dirs) { 
    $dirPath = $dirPath.Substring(2)
    Add-Content -Path $dirCsv $dirPath
}

# Get all YAML files and list out their relative paths. 
$files = gci $base -Filter "*.yml" -Recurse | Resolve-Path -Relative
foreach ($filePath in $files) {
    $fileName = Split-Path $filePath -Leaf
    $filePath = Split-Path $filePath -Parent

    if ($filePath -eq ".") {
        $filePath = ""
    } else {
        $filePath = $filePath.Substring(2)
    }

    $entry = "$filePath,$fileName"
    Add-Content -Path $filesCsv $entry    
}

pop-location 