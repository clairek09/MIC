﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Learn.BAG.Productivity;
using System;
using Microsoft.Azure.KeyVault;
using Microsoft.Azure.KeyVault.Models;
using System.Threading.Tasks;

namespace Microsoft.Learn.BAG.Productivity.Tests
{
    [TestClass()]
    public class NotificationsTests
    {
        [TestMethod()]
        public void SendO365EMailTest()
        {
            string SecretsURI = "https://bagkeyvault.vault.azure.net";

            KeyVaultClient kvc = new KeyVaultClient(new KeyVaultClient.AuthenticationCallback(Utility.GetToken));

            SecretBundle secret = Task.Run(() => kvc.GetSecretAsync(
    $"{SecretsURI}/secrets/BAGSystemAccount")).ConfigureAwait(false).GetAwaiter().GetResult();

            string email = secret.Value;

            secret = Task.Run(() => kvc.GetSecretAsync(
    $"{SecretsURI}/secrets/BAGSystemAccountPassword")).ConfigureAwait(false).GetAwaiter().GetResult();

            string pw = secret.Value;
            NotificationEMail notify = new NotificationEMail(email, pw, "REDMOND");

            try
            {
                Notifications.SendO365HTMLEmail(notify, new[] { "jayallen@microsoft.com" }, "Test Email from Code", "This is a test email. We did it!");
            } catch (Exception ex)
            {
                Assert.Fail(ex.ToString());
            }

            
        }
    }
}