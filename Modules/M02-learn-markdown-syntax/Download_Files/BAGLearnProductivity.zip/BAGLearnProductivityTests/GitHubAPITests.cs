﻿using Microsoft.Learn.BAG.Productivity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RestSharp;
using Newtonsoft.Json.Linq;
using System.Linq;
using System.Runtime.InteropServices;

namespace Microsoft.Learn.BAG.Productivity.Tests
{
    [TestClass()]
    public class GitHubAPITests
    {
        [TestMethod()]
        public void GetPullRequestsTest()
        {
            GitHubAPI gh = new GitHubAPI("MicrosoftDocs/learn-dynamics-pr", "https://githubwebhook");

            IRestResponse resp = gh.GetPullRequests(GitHubPullRequestState.Closed, null);

            var prData = JArray.Parse(resp.Content);
            foreach (var pr in prData.Root)
            {
                if (pr["state"].ToString() != "closed")
                {
                    Assert.Fail("Found a return result that isn't closed - something is wrong with the request!");
                }
            }

            // Validate we get a second page of results back.
            resp = gh.GetPullRequests(GitHubPullRequestState.Closed, resp);
            Assert.IsNotNull(resp);
        }

        [TestMethod()]
        public void GetPullRequestCommentsTest()
        {
            GitHubAPI gh = new GitHubAPI("MicrosoftDocs/learn-dynamics-pr", "https://githubwebhook");

            IRestResponse resp = gh.GetPullRequestIssuesComments(1571, null);

            // Except seven comments on this issue. 
            JArray prData = JArray.Parse(resp.Content);
            Assert.AreEqual(prData.Root.Count(), 7);

            // Assure paging works properly - in this case, a second request should cause the IRestResponse to come back as null. 
            resp = gh.GetPullRequestIssuesComments(1571, resp);
            Assert.IsNull(resp);
        }

        [TestMethod()]
        public void GetPullRequestFilesTest()
        {
            // Assure a single result from this issue. 
            GitHubAPI gh = new GitHubAPI("MicrosoftDocs/learn-dynamics-pr", "https://githubwebhook");
            IRestResponse resp = gh.GetPullRequestFiles(1571, null);

            JArray prData = JArray.Parse(resp.Content);
            Assert.AreEqual(prData.Root.Count(), 1);

            // Assure no second page of results. 
            resp = gh.GetPullRequestFiles(1571, resp);
            Assert.IsNull(resp);
        }

        [TestMethod()]
        public void FindInIssueCommentsTest()
        {
            // Find a comment we know exists. 
            GitHubAPI gh = new GitHubAPI("MicrosoftDocs/learn-dynamics-pr", "https://githubwebhook");
            JToken token = gh.FindInIssueComments(1571, "#sign-off");
            Assert.IsNotNull(token);

            // Try and find one that we know doesn't. 
            token = gh.FindInIssueComments(1571, "#foobarpandabrains");
            Assert.IsNull(token);
        }

        [TestMethod()]
        public void CreateAndClosePullRequest()
        {
            GitHubAPI gh = new GitHubAPI("MicrosoftDocs/learn-sandbox-pr", "https://githubwebhook");
            IRestResponse resp = gh.CreatePullRequest("Test pull request", "MicrosoftDocs:jaytestsource", "jaytesttarget", "Testing out creating a PR.");

            JObject jsonData = JObject.Parse(resp.Content);
            string pullNumber = (string)jsonData["number"];

            // Add a comment to the PR about why we're closing it. 
            gh.AddIssueComment(pullNumber, "Closing because this PR has been open longer than 30 days. You may re-create this pull request if you wish to continue working on it.");

            // Close it. 
            resp = gh.ClosePullRequest(pullNumber);
        }
    }


}